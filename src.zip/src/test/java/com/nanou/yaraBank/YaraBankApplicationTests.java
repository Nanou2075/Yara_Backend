package com.nanou.yaraBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YaraBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
