package com.nanou.yaraBank.exception.enums;

public enum UserType {
    SHOP,
    ADMIN,
    SPACE,

}
