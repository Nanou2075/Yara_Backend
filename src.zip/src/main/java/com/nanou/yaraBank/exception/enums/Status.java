package com.nanou.yaraBank.exception.enums;

public enum Status {
    ONLINE, OFFLINE
}
