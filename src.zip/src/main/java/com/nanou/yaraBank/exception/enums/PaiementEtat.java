package com.nanou.yaraBank.exception.enums;

public enum PaiementEtat {
    NO_PAYE,
    PAYE,
    DETTE,
}
