package com.nanou.yaraBank.exception.enums;

public enum PaiementType {
    SCOLARITE,
    DEPENSE,
    SALAIRE


}
