package com.nanou.yaraBank.exception.enums;

public enum UserStatus {
    VALIDER,
    ATTENTE,
    REJETER
}
