package com.nanou.yaraBank.exception.enums;

public enum PaiementMode {
    CHEQUE,
    ESPECE,
    VIREMENT,
    VISA
}
