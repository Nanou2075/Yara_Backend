package com.nanou.yaraBank.exception.enums;

public enum HistoryType {
    INSCRIPTION,
    SALE,

    ASKING
}
