package com.nanou.yaraBank.history;

public class HistoryServiceImpl {
}
