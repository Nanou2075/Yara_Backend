package com.nanou.yaraBank.history;

public interface HistoryService {
}
