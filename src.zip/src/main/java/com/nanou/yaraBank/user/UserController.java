

package com.nanou.yaraBank.user;

public class UserController
{
}
