
package com.nanou.yaraBank.user;

public interface UserResource {
}
