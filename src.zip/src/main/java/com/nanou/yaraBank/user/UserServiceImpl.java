
package com.nanou.yaraBank.user;

public class UserServiceImpl
{
}
