package com.nanou.yaraBank.security.authentication;

public record AuthenticationRequest(String username, String password
) {
}
