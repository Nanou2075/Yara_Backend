package com.nanou.yaraBank.security.password;

public record ForgetPasswordRequestDTO(
        String email
) {
}
