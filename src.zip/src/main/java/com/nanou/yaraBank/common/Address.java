package com.nanou.yaraBank.common;

public class Address {
}
