
package com.nanou.yaraBank.enterprise;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SuggestionRepository extends JpaRepository<SuggestionDomain,String> {
}
