package com.nanou.yaraBank.enums;

public enum Role {
    AGENCE,
    CLIENT,

}
