package com.nanou.yaraBank.enums;

public enum AccountType {
    EPARGNE,
    COURANT,
    JOINT
}
