package com.nanou.yaraBank.enums;

public enum CustomerType {
    ENTREPRISE,
    PERSONNEL
}
