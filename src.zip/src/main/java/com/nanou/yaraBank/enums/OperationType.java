package com.nanou.yaraBank.enums;

public enum OperationType {
    DEBIT, CREDIT
}
