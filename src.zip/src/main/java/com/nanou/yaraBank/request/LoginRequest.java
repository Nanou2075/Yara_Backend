package com.nanou.yaraBank.request;

public record LoginRequest(String username, String password) {
}
